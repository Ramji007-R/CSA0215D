# Public Transport Seat Reservation and Passenger Management System

A complete, dual-implementation project for public transport seat reservation and passenger fleet management:
1. **Interactive Static Web Application (HTML5, CSS3, Vanilla JavaScript, Bootstrap 5, LocalStorage)** — Ready for instant Netlify drag-and-drop deployment.
2. **C Programming Terminal Console Application (`bus_reservation.c`)** — Clean, compilable ANSI C / C99 program with Date & Time Slot selection (Morning, Afternoon, Evening, Night) displaying all scheduled buses and handling seat reservations.

---

## 💻 C Programming Console Module (`bus_reservation.c`)

The academic C program implements bus schedule lookup, time slot filtering, realistic 40-seat coach rendering, and passenger ticketing.

### Key Capabilities in C:
1. **Travel Date Selection**: Prompts the user to enter a travel date (e.g., `2026-11-25` or `DD-MM-YYYY`).
2. **Time Slot Selection**:
   - `[1] Morning   (06:00 AM - 11:59 AM)`
   - `[2] Afternoon (12:00 PM - 04:59 PM)`
   - `[3] Evening   (05:00 PM - 08:59 PM)`
   - `[4] Night     (09:00 PM - 05:59 AM)`
   - `[5] All Slots (Show All Operating Buses)`
3. **Displays Every Operating Bus**:
   - Formatted ASCII table showing:
     - Bus ID & Coach Number
     - Service Name & Coach Type (AC Sleeper, Luxury Seater, Express)
     - Origin & Destination Terminals
     - Exact Departure & Arrival Times
     - Live Available Seats Counter (`X / 40 Seats Available`)
     - Ticket Fare per Seat
4. **40-Seat Coach Layout**:
   - Realistic 10-row ASCII bus layout with central aisle (`[ 01 ] [ 02 ] || AISLE || [ 03 ] [ 04 ]`), Driver Cabin, Entrance Door, and Rear Emergency Exit.
   - Available seats displayed as `[ 05 ]`; booked seats displayed as `[ XX ]`.
5. **Passenger Registration & Ticket Generation**:
   - Prompts for Passenger Name, Age, Gender, and 10-digit Mobile Number.
   - Generates unique ID (`PTS-XXXXXX`) and prints a formatted boarding pass.
6. **Cancellation & Seat Release**:
   - Releases the cancelled seat immediately back to the available pool.
7. **Admin Analytics Dashboard**:
   - Overall fleet capacity, booked vs available seats, occupancy percentage, and revenue.

### How to Compile & Run the C Program:

```bash
# Using GCC (MinGW on Windows, GCC on Linux/macOS):
gcc bus_reservation.c -o bus_reservation
./bus_reservation        # On Windows: bus_reservation.exe

# Using Clang:
clang bus_reservation.c -o bus_reservation
./bus_reservation

# Using Microsoft Visual C++ (cl):
cl bus_reservation.c
bus_reservation.exe
```

---

## 🌐 Web Application (Netlify Ready)

### 🎨 Design System & Color Palette
- **Primary Color**: `#38BDF8` (Sky Blue accents, highlights, badges)
- **Secondary Color**: `#0EA5E9` (Deep sky blue, action buttons, active tabs)
- **Background**: `#F0F9FF` (Soft sky-blue tint background)
- **Cards & Modals**: `#FFFFFF` (Pure white cards with rounded corners and soft drop shadows)
- **Text**: `#0F172A` (Slate dark typography with `Plus Jakarta Sans`)
- **Seat Status Indicators**:
  - 🟢 **Available**: `#22C55E` / `#DCFCE7` (Green)
  - 🔵 **Selected**: `#0EA5E9` (Sky Blue with pulse glow effect)
  - ⚪ **Booked**: `#94A3B8` / `#E2E8F0` (Grey, locked and unclickable)

### ✨ Key Features Implemented:
1. **Date & Time Slot Bus Filtering**:
   - Users pick Travel Date and Time Slot (`All`, `Morning`, `Afternoon`, `Evening`, `Night`).
   - Dynamically shows every coach scheduled for that date and time slot with live seat availability.
   - Clicking "Select Coach" instantly switches the 40-seat coach map to that specific bus.
2. **Realistic 40-Seat Interactive Bus Layout**:
   - 10 rows (2x2 layout with central aisle).
   - Seats tracked independently per coach and travel date.
3. **Passenger Registration & Input Validation**:
   - Full Name, Age (1-120), Gender, and 10-digit Mobile Number.
4. **Instant Printable Ticket / Boarding Pass**:
   - Includes Travel Date, Time Slot, Coach Number, Departure Time, Seat Numbers, Transit Barcode (`Libre Barcode 39`), and `@media print` clean styling.
5. **My Bookings & Search**:
   - Search by Booking ID or Mobile Number.
   - Real-time cancellation that immediately releases seats back to the open pool.
6. **Administrator Dashboard**:
   - Fleet occupancy analytics, booking records table, and JSON export.
   - Demo Credentials: Username `admin` | Password `admin123`.

---

## 📁 Project Directory Structure

```text
passenger-bus-booking/
├── index.html                   # Single Page Web App (Home, Schedule, Seat Map, Admin, Modals)
├── _redirects                   # Netlify routing rules
├── netlify.toml                 # Netlify static headers & configuration
├── bus_reservation.c            # Standalone C Program (Date & Time Slot Schedule & Reservation)
├── c_program/
│   ├── bus_reservation.c       # C Program copy in dedicated folder
│   └── HOW_TO_RUN_C_PROGRAM.txt# Compilation and execution guide
├── css/
│   └── style.css                # Sky Blue theme, bus cabin grid, and print styles
├── js/
│   ├── storage.js               # Multi-bus fleet data, LocalStorage layer, and statistics
│   └── app.js                   # Date/Slot schedule filtering, seat selection, and UI logic
└── README.md                    # Project documentation
```

---

## ☁️ How to Deploy to Netlify (Drag & Drop)

1. Log into your [Netlify](https://app.netlify.com/) account.
2. Go to the **Sites** tab.
3. Drag and drop the `passenger-bus-booking` folder into the Netlify Drop area.
4. Netlify will deploy the site with a live URL within seconds!
