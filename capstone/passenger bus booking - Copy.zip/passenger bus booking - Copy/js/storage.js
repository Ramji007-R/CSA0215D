/**
 * Storage & Data Management Module
 * Uses Browser LocalStorage for persistence
 * Public Transport Seat Reservation and Passenger Management System
 */

(function (window) {
  'use strict';

  const STORAGE_KEYS = {
    BOOKINGS: 'PTS_RESERVATIONS_DATA',
    BUS_CONFIG: 'PTS_BUS_CONFIG',
    ADMIN_SESSION: 'PTS_ADMIN_SESSION',
    SELECTED_BUS_ID: 'PTS_SELECTED_BUS_ID',
    SELECTED_DATE: 'PTS_SELECTED_DATE',
    SELECTED_SLOT: 'PTS_SELECTED_SLOT'
  };

  // Comprehensive fleet of scheduled buses categorized by time slots
  const FLEET_SCHEDULE = [
    /* --- MORNING BUSES (06:00 AM - 11:59 AM) --- */
    {
      id: 101,
      busNumber: 'SKY-101-EXP',
      serviceName: 'SkyRoute Sunrise Express',
      slot: 'Morning',
      slotTimeRange: '06:00 AM - 11:59 AM',
      departureTime: '07:00 AM',
      arrivalTime: '11:15 AM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 1)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 22.00,
      busType: 'Executive AC Seater',
      totalSeats: 40
    },
    {
      id: 102,
      busNumber: 'SKY-102-EXP',
      serviceName: 'Coastal Breeze Superfast',
      slot: 'Morning',
      slotTimeRange: '06:00 AM - 11:59 AM',
      departureTime: '09:30 AM',
      arrivalTime: '01:45 PM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 4)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 25.00,
      busType: 'Luxury Air-Suspension Coach',
      totalSeats: 40
    },
    {
      id: 103,
      busNumber: 'SKY-103-EXP',
      serviceName: 'Northway Morning Express',
      slot: 'Morning',
      slotTimeRange: '06:00 AM - 11:59 AM',
      departureTime: '11:00 AM',
      arrivalTime: '03:15 PM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 2)',
      routeTo: 'North Valley Station',
      farePerSeat: 20.00,
      busType: 'Semi-Sleeper AC Coach',
      totalSeats: 40
    },

    /* --- AFTERNOON BUSES (12:00 PM - 04:59 PM) --- */
    {
      id: 201,
      busNumber: 'SKY-201-EXP',
      serviceName: 'Skyline Midday Cruiser',
      slot: 'Afternoon',
      slotTimeRange: '12:00 PM - 04:59 PM',
      departureTime: '01:15 PM',
      arrivalTime: '05:30 PM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 3)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 25.00,
      busType: 'Air-Suspension Luxury Seater',
      totalSeats: 40
    },
    {
      id: 202,
      busNumber: 'SKY-202-EXP',
      serviceName: 'Highland Afternoon Swift',
      slot: 'Afternoon',
      slotTimeRange: '12:00 PM - 04:59 PM',
      departureTime: '03:45 PM',
      arrivalTime: '08:00 PM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 5)',
      routeTo: 'Highland Hill Terminal',
      farePerSeat: 28.00,
      busType: 'AC Air-Sleeper Coach',
      totalSeats: 40
    },

    /* --- EVENING BUSES (05:00 PM - 08:59 PM) --- */
    {
      id: 301,
      busNumber: 'SKY-301-EXP',
      serviceName: 'Golden Coast Sunset Express',
      slot: 'Evening',
      slotTimeRange: '05:00 PM - 08:59 PM',
      departureTime: '05:30 PM',
      arrivalTime: '09:45 PM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 4)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 27.00,
      busType: 'Luxury Sleeper / Seater',
      totalSeats: 40
    },
    {
      id: 302,
      busNumber: 'SKY-302-EXP',
      serviceName: 'Metro Twilight Shuttle',
      slot: 'Evening',
      slotTimeRange: '05:00 PM - 08:59 PM',
      departureTime: '07:15 PM',
      arrivalTime: '09:30 PM',
      travelDuration: '2h 15m',
      routeFrom: 'Metro Central Terminal (Platform 1)',
      routeTo: 'Airport Express Hub',
      farePerSeat: 18.00,
      busType: 'City Express Rapid AC',
      totalSeats: 40
    },
    {
      id: 303,
      busNumber: 'SKY-303-EXP',
      serviceName: 'Pacific Shore Evening Runner',
      slot: 'Evening',
      slotTimeRange: '05:00 PM - 08:59 PM',
      departureTime: '08:30 PM',
      arrivalTime: '12:45 AM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 3)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 25.00,
      busType: 'Air-Suspension Coach',
      totalSeats: 40
    },

    /* --- NIGHT BUSES (09:00 PM - 05:59 AM) --- */
    {
      id: 401,
      busNumber: 'SKY-401-EXP',
      serviceName: 'Night Owl AC Sleeper Coach',
      slot: 'Night',
      slotTimeRange: '09:00 PM - 05:59 AM',
      departureTime: '10:15 PM',
      arrivalTime: '02:30 AM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 6)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 30.00,
      busType: 'Luxury AC Sleeper',
      totalSeats: 40
    },
    {
      id: 402,
      busNumber: 'SKY-402-EXP',
      serviceName: 'Starline Midnight Express',
      slot: 'Night',
      slotTimeRange: '09:00 PM - 05:59 AM',
      departureTime: '11:45 PM',
      arrivalTime: '04:15 AM',
      travelDuration: '4h 30m',
      routeFrom: 'Metro Central Terminal (Platform 2)',
      routeTo: 'South Port Station',
      farePerSeat: 32.00,
      busType: 'Multi-Axle Super Sleeper',
      totalSeats: 40
    },
    {
      id: 403,
      busNumber: 'SKY-403-EXP',
      serviceName: 'Dawn Star Early Highway Rider',
      slot: 'Night',
      slotTimeRange: '09:00 PM - 05:59 AM',
      departureTime: '04:30 AM',
      arrivalTime: '08:45 AM',
      travelDuration: '4h 15m',
      routeFrom: 'Metro Central Terminal (Platform 5)',
      routeTo: 'Ocean Bay Coastal Station',
      farePerSeat: 24.00,
      busType: 'Executive Seater Coach',
      totalSeats: 40
    }
  ];

  // Default initial demo bookings clearly labeled
  const DEMO_BOOKINGS = [
    {
      id: 'PTS-104921',
      passenger: {
        name: 'Dr. Sarah Jenkins',
        age: 34,
        gender: 'Female',
        mobile: '9876543210'
      },
      seats: [5, 6],
      seatsCount: 2,
      farePerSeat: 25.00,
      totalAmount: 50.00,
      travelDate: '2026-11-25',
      timeSlot: 'Morning',
      bookingDate: '2026-11-20 09:15 AM',
      status: 'Confirmed',
      busDetails: {
        busId: 102,
        busNumber: 'SKY-102-EXP',
        serviceName: 'Coastal Breeze Superfast',
        routeFrom: 'Metro Central Terminal (Platform 4)',
        routeTo: 'Ocean Bay Coastal Station',
        departureTime: '09:30 AM',
        slot: 'Morning'
      },
      isDemo: true
    },
    {
      id: 'PTS-295014',
      passenger: {
        name: 'Alex Rivera',
        age: 28,
        gender: 'Male',
        mobile: '9812345678'
      },
      seats: [14],
      seatsCount: 1,
      farePerSeat: 25.00,
      totalAmount: 25.00,
      travelDate: '2026-11-25',
      timeSlot: 'Afternoon',
      bookingDate: '2026-11-20 10:40 AM',
      status: 'Confirmed',
      busDetails: {
        busId: 201,
        busNumber: 'SKY-201-EXP',
        serviceName: 'Skyline Midday Cruiser',
        routeFrom: 'Metro Central Terminal (Platform 3)',
        routeTo: 'Ocean Bay Coastal Station',
        departureTime: '01:15 PM',
        slot: 'Afternoon'
      },
      isDemo: true
    },
    {
      id: 'PTS-401928',
      passenger: {
        name: 'David Miller',
        age: 39,
        gender: 'Male',
        mobile: '9898981234'
      },
      seats: [22],
      seatsCount: 1,
      farePerSeat: 30.00,
      totalAmount: 30.00,
      travelDate: '2026-11-25',
      timeSlot: 'Night',
      bookingDate: '2026-11-21 03:20 PM',
      status: 'Confirmed',
      busDetails: {
        busId: 401,
        busNumber: 'SKY-401-EXP',
        serviceName: 'Night Owl AC Sleeper Coach',
        routeFrom: 'Metro Central Terminal (Platform 6)',
        routeTo: 'Ocean Bay Coastal Station',
        departureTime: '10:15 PM',
        slot: 'Night'
      },
      isDemo: true
    },
    {
      id: 'PTS-389102',
      passenger: {
        name: 'Michael Chang',
        age: 45,
        gender: 'Male',
        mobile: '9845612300'
      },
      seats: [23],
      seatsCount: 1,
      farePerSeat: 25.00,
      totalAmount: 25.00,
      travelDate: '2026-11-24',
      timeSlot: 'Evening',
      bookingDate: '2026-11-18 02:40 PM',
      status: 'Cancelled',
      cancelledDate: '2026-11-19 09:00 AM',
      cancelReason: 'Change of schedule',
      busDetails: {
        busId: 301,
        busNumber: 'SKY-301-EXP',
        serviceName: 'Golden Coast Sunset Express',
        routeFrom: 'Metro Central Terminal (Platform 4)',
        routeTo: 'Ocean Bay Coastal Station',
        departureTime: '05:30 PM',
        slot: 'Evening'
      },
      isDemo: true
    }
  ];

  const BusStorage = {
    /**
     * Initializes storage with demo data if empty
     */
    init: function () {
      if (!localStorage.getItem(STORAGE_KEYS.BOOKINGS)) {
        this.resetDemoData();
      }
      if (!localStorage.getItem(STORAGE_KEYS.SELECTED_BUS_ID)) {
        localStorage.setItem(STORAGE_KEYS.SELECTED_BUS_ID, '102');
      }
      if (!localStorage.getItem(STORAGE_KEYS.SELECTED_SLOT)) {
        localStorage.setItem(STORAGE_KEYS.SELECTED_SLOT, 'ALL');
      }
    },

    /**
     * Returns full fleet of scheduled buses
     */
    getFleet: function () {
      return FLEET_SCHEDULE;
    },

    /**
     * Get a specific bus by ID
     */
    getBusById: function (busId) {
      const id = parseInt(busId, 10);
      const found = FLEET_SCHEDULE.find(b => b.id === id);
      return found || FLEET_SCHEDULE[1]; // Default to Bus 102
    },

    /**
     * Get currently selected bus
     */
    getSelectedBus: function () {
      const id = localStorage.getItem(STORAGE_KEYS.SELECTED_BUS_ID) || '102';
      return this.getBusById(id);
    },

    /**
     * Set active selected bus
     */
    setSelectedBus: function (busId) {
      localStorage.setItem(STORAGE_KEYS.SELECTED_BUS_ID, String(busId));
    },

    /**
     * Get and Set selected Travel Date
     */
    getSelectedDate: function () {
      const stored = localStorage.getItem(STORAGE_KEYS.SELECTED_DATE);
      if (stored) return stored;
      // Default to 2026-11-25 or current local ISO date
      const d = new Date();
      return d.toISOString().slice(0, 10);
    },

    setSelectedDate: function (dateStr) {
      localStorage.setItem(STORAGE_KEYS.SELECTED_DATE, dateStr);
    },

    /**
     * Get and Set selected Time Slot filter
     */
    getSelectedSlot: function () {
      return localStorage.getItem(STORAGE_KEYS.SELECTED_SLOT) || 'ALL';
    },

    setSelectedSlot: function (slot) {
      localStorage.setItem(STORAGE_KEYS.SELECTED_SLOT, slot);
    },

    /**
     * Get buses matching Date and Time Slot
     */
    getBusesByDateAndSlot: function (travelDate, slot) {
      const targetSlot = (slot || 'ALL').toUpperCase();
      return FLEET_SCHEDULE.filter(bus => {
        if (targetSlot === 'ALL') return true;
        return bus.slot.toUpperCase() === targetSlot;
      });
    },

    /**
     * Backward-compatible config getter
     */
    getConfig: function () {
      const bus = this.getSelectedBus();
      return {
        totalSeats: bus.totalSeats || 40,
        farePerSeat: bus.farePerSeat,
        busNumber: bus.busNumber,
        serviceName: bus.serviceName,
        routeFrom: bus.routeFrom,
        routeTo: bus.routeTo,
        departureTime: bus.departureTime,
        travelDuration: bus.travelDuration,
        busType: bus.busType,
        slot: bus.slot
      };
    },

    /**
     * Returns all stored bookings
     */
    getAllBookings: function () {
      try {
        const data = localStorage.getItem(STORAGE_KEYS.BOOKINGS);
        return data ? JSON.parse(data) : [];
      } catch (e) {
        console.error('Error reading bookings from LocalStorage:', e);
        return [];
      }
    },

    /**
     * Returns list of currently booked seat numbers for a specific bus & date
     */
    getBookedSeatNumbers: function (busId, travelDate) {
      const targetBusId = busId ? parseInt(busId, 10) : parseInt(this.getSelectedBus().id, 10);
      const targetDate = travelDate || this.getSelectedDate();
      const bookings = this.getAllBookings();
      const bookedSeats = [];

      bookings.forEach(function (b) {
        if (b.status === 'Confirmed' && Array.isArray(b.seats)) {
          // Match by busId and optionally date
          const bBusId = b.busDetails ? parseInt(b.busDetails.busId, 10) : 102;
          const bDate = b.travelDate || '';

          // If date matches and busId matches, or legacy record
          const busMatches = bBusId === targetBusId;
          const dateMatches = !targetDate || !bDate || bDate === targetDate;

          if (busMatches && dateMatches) {
            b.seats.forEach(function (seat) {
              bookedSeats.push(Number(seat));
            });
          }
        }
      });
      return bookedSeats;
    },

    /**
     * Check if a specific seat is currently booked on the current bus
     */
    isSeatBooked: function (seatNumber, busId, travelDate) {
      const booked = this.getBookedSeatNumbers(busId, travelDate);
      return booked.includes(Number(seatNumber));
    },

    /**
     * Generate unique booking ID
     */
    generateBookingId: function () {
      const randomNum = Math.floor(100000 + Math.random() * 900000);
      return `PTS-${randomNum}`;
    },

    /**
     * Save a new booking
     */
    createBooking: function (bookingData) {
      if (!bookingData || !bookingData.seats || !Array.isArray(bookingData.seats) || bookingData.seats.length === 0) {
        return {
          success: false,
          message: 'Please select at least one seat to book.'
        };
      }

      const bookings = this.getAllBookings();
      const busId = bookingData.busId || this.getSelectedBus().id;
      const bus = this.getBusById(busId);
      const travelDate = bookingData.travelDate || this.getSelectedDate();

      // Check for seat conflicts specifically on this bus and date
      const bookedSeats = this.getBookedSeatNumbers(bus.id, travelDate);
      const requestedSeats = bookingData.seats.map(Number);
      
      const hasConflict = requestedSeats.some(seat => bookedSeats.includes(seat));
      if (hasConflict) {
        return {
          success: false,
          message: 'One or more selected seats were already booked on this coach. Please choose another seat.'
        };
      }

      const now = new Date();
      const formattedDate = now.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      }) + ' ' + now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      });

      const newBooking = {
        id: this.generateBookingId(),
        passenger: {
          name: bookingData.passenger.name.trim(),
          age: parseInt(bookingData.passenger.age, 10),
          gender: bookingData.passenger.gender,
          mobile: bookingData.passenger.mobile.trim()
        },
        seats: requestedSeats.sort((a, b) => a - b),
        seatsCount: requestedSeats.length,
        farePerSeat: bus.farePerSeat,
        totalAmount: requestedSeats.length * bus.farePerSeat,
        travelDate: travelDate,
        timeSlot: bus.slot,
        bookingDate: formattedDate,
        status: 'Confirmed',
        busDetails: {
          busId: bus.id,
          busNumber: bus.busNumber,
          serviceName: bus.serviceName,
          routeFrom: bus.routeFrom,
          routeTo: bus.routeTo,
          departureTime: bus.departureTime,
          slot: bus.slot,
          busType: bus.busType
        },
        isDemo: false
      };

      bookings.unshift(newBooking);
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));

      return {
        success: true,
        booking: newBooking
      };
    },

    /**
     * Find booking by ID
     */
    getBookingById: function (bookingId) {
      if (!bookingId) return null;
      const cleanId = bookingId.trim().toUpperCase();
      const bookings = this.getAllBookings();
      return bookings.find(b => b.id.toUpperCase() === cleanId) || null;
    },

    /**
     * Search bookings by ID or Mobile Number or Passenger Name
     */
    searchBookings: function (query) {
      if (!query) return [];
      const clean = query.trim().toLowerCase();
      const bookings = this.getAllBookings();

      return bookings.filter(b => {
        const matchId = b.id.toLowerCase().includes(clean);
        const matchMobile = b.passenger && b.passenger.mobile && b.passenger.mobile.includes(clean);
        const matchName = b.passenger && b.passenger.name && b.passenger.name.toLowerCase().includes(clean);
        const matchBus = b.busDetails && b.busDetails.busNumber && b.busDetails.busNumber.toLowerCase().includes(clean);
        return matchId || matchMobile || matchName || matchBus;
      });
    },

    /**
     * Cancel a booking by ID and release seat back to pool
     */
    cancelBooking: function (bookingId, reason) {
      const cleanId = bookingId.trim().toUpperCase();
      const bookings = this.getAllBookings();
      const bookingIndex = bookings.findIndex(b => b.id.toUpperCase() === cleanId);

      if (bookingIndex === -1) {
        return {
          success: false,
          message: 'Booking not found.'
        };
      }

      if (bookings[bookingIndex].status === 'Cancelled') {
        return {
          success: false,
          message: 'This reservation is already cancelled.'
        };
      }

      const now = new Date();
      bookings[bookingIndex].status = 'Cancelled';
      bookings[bookingIndex].cancelledDate = now.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      }) + ' ' + now.toLocaleTimeString('en-US', {
        hour: '2-digit',
        minute: '2-digit'
      });
      bookings[bookingIndex].cancelReason = reason || 'Customer requested cancellation';

      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));

      return {
        success: true,
        booking: bookings[bookingIndex],
        message: `Booking ${cleanId} successfully cancelled. Seat(s) released.`
      };
    },

    /**
     * Get computed statistics for dashboard and home
     */
    getStatistics: function () {
      const bookings = this.getAllBookings();
      const currentBus = this.getSelectedBus();
      const currentDate = this.getSelectedDate();
      const bookedSeats = this.getBookedSeatNumbers(currentBus.id, currentDate);

      const totalSeats = currentBus.totalSeats || 40;
      const bookedCount = bookedSeats.length;
      const availableCount = Math.max(0, totalSeats - bookedCount);
      const totalBookings = bookings.length;
      const activeBookings = bookings.filter(b => b.status === 'Confirmed').length;
      const cancelledBookings = bookings.filter(b => b.status === 'Cancelled').length;

      const totalRevenue = bookings
        .filter(b => b.status === 'Confirmed')
        .reduce((sum, b) => sum + (Number(b.totalAmount) || 0), 0);

      const occupancyPercent = totalSeats > 0 ? Math.round((bookedCount / totalSeats) * 100) : 0;

      return {
        totalSeats,
        bookedSeatsCount: bookedCount,
        availableSeatsCount: availableCount,
        totalBookingsCount: totalBookings,
        activeBookingsCount: activeBookings,
        cancelledBookingsCount: cancelledBookings,
        totalRevenue: totalRevenue.toFixed(2),
        occupancyPercent,
        totalBusesCount: FLEET_SCHEDULE.length
      };
    },

    /**
     * Reset demo data
     */
    resetDemoData: function () {
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify(DEMO_BOOKINGS));
      localStorage.setItem(STORAGE_KEYS.SELECTED_BUS_ID, '102');
      localStorage.setItem(STORAGE_KEYS.SELECTED_SLOT, 'ALL');
    },

    /**
     * Clear all records
     */
    clearAllData: function () {
      localStorage.setItem(STORAGE_KEYS.BOOKINGS, JSON.stringify([]));
    },

    /**
     * Admin Authentication Management
     */
    isAdminLoggedIn: function () {
      return sessionStorage.getItem(STORAGE_KEYS.ADMIN_SESSION) === 'true';
    },

    loginAdmin: function (username, password) {
      if (username === 'admin' && password === 'admin123') {
        sessionStorage.setItem(STORAGE_KEYS.ADMIN_SESSION, 'true');
        return true;
      }
      return false;
    },

    logoutAdmin: function () {
      sessionStorage.removeItem(STORAGE_KEYS.ADMIN_SESSION);
    }
  };

  // Expose to global window
  window.BusStorage = BusStorage;
  BusStorage.init();

})(window);
