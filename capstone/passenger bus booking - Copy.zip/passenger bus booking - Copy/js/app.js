/**
 * Public Transport Seat Reservation and Passenger Management System
 * Main Application Logic (Vanilla JavaScript)
 */

(function (window, document) {
  'use strict';

  // Global Application Object
  const PTSApp = {
    selectedSeats: [],
    currentView: 'home',
    statusFilter: 'ALL',
    pendingCancelId: null,
    ticketModalInstance: null,
    cancelModalInstance: null,

    /**
     * App Initialization
     */
    init: function () {
      // Initialize Bootstrap Modals
      const ticketModalEl = document.getElementById('ticketModal');
      if (ticketModalEl && window.bootstrap) {
        this.ticketModalInstance = new bootstrap.Modal(ticketModalEl);
      }

      const cancelModalEl = document.getElementById('cancelModal');
      if (cancelModalEl && window.bootstrap) {
        this.cancelModalInstance = new bootstrap.Modal(cancelModalEl);
      }

      // Initialize Date inputs with minimum date = today
      const todayIso = new Date().toISOString().slice(0, 10);
      const scheduleDateInput = document.getElementById('schedule-travel-date');
      const homeDateInput = document.getElementById('home-search-date');

      const initialDate = window.BusStorage ? BusStorage.getSelectedDate() : todayIso;

      if (scheduleDateInput) {
        scheduleDateInput.min = todayIso;
        scheduleDateInput.value = initialDate;
      }
      if (homeDateInput) {
        homeDateInput.min = todayIso;
        homeDateInput.value = initialDate;
      }

      // Sync time slot buttons with stored slot
      const initialSlot = window.BusStorage ? BusStorage.getSelectedSlot() : 'ALL';
      this.syncTimeSlotButtons(initialSlot);

      // Handle URL hash changes
      window.addEventListener('hashchange', () => {
        const hash = window.location.hash.replace('#', '') || 'home';
        this.navigate(hash);
      });

      // Initial route
      const initialHash = window.location.hash.replace('#', '') || 'home';
      this.navigate(initialHash);

      // Render initial dashboard stats
      this.updateHomeStats();
    },

    /**
     * SPA View Navigation
     */
    navigate: function (viewName) {
      const validViews = ['home', 'book', 'my-bookings', 'admin'];
      const targetView = validViews.includes(viewName) ? viewName : 'home';
      this.currentView = targetView;

      // Update Navigation Bar active states
      document.querySelectorAll('.navbar-nav .nav-link').forEach(link => {
        link.classList.remove('active');
      });
      const activeNav = document.getElementById(`nav-${targetView}`);
      if (activeNav) {
        activeNav.classList.add('active');
      }

      // Hide all SPA sections
      document.querySelectorAll('.spa-view').forEach(view => {
        view.classList.add('d-none');
      });

      // Show the selected view
      const activeSection = document.getElementById(`view-${targetView}`);
      if (activeSection) {
        activeSection.classList.remove('d-none');
      }

      // Sync URL hash without infinite loop
      if (window.location.hash !== `#${targetView}`) {
        history.replaceState(null, null, `#${targetView}`);
      }

      // Auto-collapse mobile navbar after click
      const navbarCollapse = document.getElementById('navbarContent');
      if (navbarCollapse && navbarCollapse.classList.contains('show') && window.bootstrap) {
        const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
        if (bsCollapse) bsCollapse.hide();
      }

      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });

      // View-specific render hooks
      if (targetView === 'home') {
        this.updateHomeStats();
      } else if (targetView === 'book') {
        this.renderAvailableBuses();
        this.renderSeatGrid();
        this.updateSelectionSummary();
      } else if (targetView === 'my-bookings') {
        this.renderBookingsList();
      } else if (targetView === 'admin') {
        this.renderAdminView();
      }
    },

    /**
     * Update Home Page Statistics Counters
     */
    updateHomeStats: function () {
      if (!window.BusStorage) return;
      const stats = BusStorage.getStatistics();

      const elTotal = document.getElementById('home-stat-total');
      const elAvailable = document.getElementById('home-stat-available');
      const elBooked = document.getElementById('home-stat-booked');
      const elOccupancy = document.getElementById('home-stat-occupancy');

      if (elTotal) elTotal.textContent = stats.totalSeats;
      if (elAvailable) elAvailable.textContent = stats.availableSeatsCount;
      if (elBooked) elBooked.textContent = stats.bookedSeatsCount;
      if (elOccupancy) elOccupancy.textContent = `${stats.occupancyPercent}%`;
    },

    /**
     * Quick Search from Home Page
     */
    handleHomeSearch: function () {
      const dateInput = document.getElementById('home-search-date');
      const slotSelect = document.getElementById('home-search-slot');

      if (dateInput && dateInput.value) {
        BusStorage.setSelectedDate(dateInput.value);
        const scheduleDateInput = document.getElementById('schedule-travel-date');
        if (scheduleDateInput) scheduleDateInput.value = dateInput.value;
      }

      if (slotSelect) {
        BusStorage.setSelectedSlot(slotSelect.value);
        this.syncTimeSlotButtons(slotSelect.value);
      }

      this.navigate('book');
      this.showToast('Displaying scheduled buses matching your search!', 'info');
    },

    /**
     * Set Time Slot Filter (Morning / Afternoon / Evening / Night / All)
     */
    setTimeSlotFilter: function (slot) {
      BusStorage.setSelectedSlot(slot);
      this.syncTimeSlotButtons(slot);
      this.renderAvailableBuses();
    },

    /**
     * Sync time slot filter UI buttons
     */
    syncTimeSlotButtons: function (slot) {
      const target = (slot || 'ALL').toUpperCase();
      document.querySelectorAll('.slot-filter-btn').forEach(btn => {
        if (btn.dataset.slot.toUpperCase() === target) {
          btn.classList.add('active');
        } else {
          btn.classList.remove('active');
        }
      });
    },

    /**
     * Handle Date or Slot change on the Booking page
     */
    handleScheduleFilterChange: function () {
      const dateInput = document.getElementById('schedule-travel-date');
      if (dateInput && dateInput.value) {
        BusStorage.setSelectedDate(dateInput.value);
      }

      // Re-render available buses and seat map
      this.renderAvailableBuses();
      this.selectedSeats = [];
      this.renderSeatGrid();
      this.updateSelectionSummary();
    },

    /**
     * Render the list of available buses for selected Date and Time Slot
     */
    renderAvailableBuses: function () {
      const container = document.getElementById('available-buses-container');
      const countLabel = document.getElementById('buses-result-count-label');
      if (!container || !window.BusStorage) return;

      const travelDate = BusStorage.getSelectedDate();
      const slot = BusStorage.getSelectedSlot();
      const currentBus = BusStorage.getSelectedBus();

      const matchingBuses = BusStorage.getBusesByDateAndSlot(travelDate, slot);

      if (countLabel) {
        const slotText = slot === 'ALL' ? 'All Time Slots' : `${slot} Slot`;
        countLabel.textContent = `Showing ${matchingBuses.length} Coaches for ${travelDate} (${slotText}):`;
      }

      container.innerHTML = '';

      if (matchingBuses.length === 0) {
        container.innerHTML = `
          <div class="col-12 text-center py-4 text-muted">
            <i class="bi bi-calendar-x fs-2 d-block mb-2 text-secondary"></i>
            No buses are scheduled for the selected date and time slot. Please choose another slot or date.
          </div>
        `;
        return;
      }

      matchingBuses.forEach(bus => {
        const isSelected = bus.id === currentBus.id;
        const bookedCount = BusStorage.getBookedSeatNumbers(bus.id, travelDate).length;
        const availableCount = 40 - bookedCount;

        let slotBadgeClass = 'slot-badge-morning';
        let slotIcon = '🌅';
        if (bus.slot === 'Afternoon') {
          slotBadgeClass = 'slot-badge-afternoon';
          slotIcon = '☀️';
        } else if (bus.slot === 'Evening') {
          slotBadgeClass = 'slot-badge-evening';
          slotIcon = '🌆';
        } else if (bus.slot === 'Night') {
          slotBadgeClass = 'slot-badge-night';
          slotIcon = '🌙';
        }

        const col = document.createElement('div');
        col.className = 'col-md-6 col-lg-4';

        col.innerHTML = `
          <div class="bus-card-item ${isSelected ? 'active-bus' : ''}" onclick="PTSApp.selectBus(${bus.id})">
            <div class="d-flex justify-content-between align-items-start mb-2">
              <span class="badge ${slotBadgeClass} px-2 py-1">
                ${slotIcon} ${bus.slot} (${bus.departureTime})
              </span>
              <span class="fw-bold text-primary-custom fs-5">$${bus.farePerSeat.toFixed(2)}</span>
            </div>

            <h6 class="fw-bold text-dark mb-1">${bus.serviceName}</h6>
            <div class="text-muted small mb-2">Coach #${bus.busNumber} &bull; ${bus.busType}</div>

            <div class="d-flex align-items-center gap-2 small text-muted mb-2">
              <i class="bi bi-geo-alt-fill text-danger"></i>
              <span class="text-truncate">${bus.routeFrom.split('(')[0].trim()} ➔ ${bus.routeTo.split('(')[0].trim()}</span>
            </div>

            <div class="d-flex justify-content-between align-items-center pt-2 border-top small">
              <span class="${availableCount < 5 ? 'text-danger fw-bold' : 'text-success fw-bold'}">
                <i class="bi bi-person-check-fill me-1"></i> ${availableCount} / 40 Seats Available
              </span>
              <button class="btn btn-sm ${isSelected ? 'btn-primary-custom' : 'btn-outline-custom'} py-1 px-2" style="font-size: 0.78rem;">
                ${isSelected ? 'Selected' : 'Select Coach'}
              </button>
            </div>
          </div>
        `;

        container.appendChild(col);
      });
    },

    /**
     * User selects a specific bus from the schedule
     */
    selectBus: function (busId) {
      BusStorage.setSelectedBus(busId);
      this.selectedSeats = [];
      this.renderAvailableBuses();
      this.renderSeatGrid();
      this.updateSelectionSummary();

      const bus = BusStorage.getBusById(busId);
      this.showToast(`Selected Coach: ${bus.serviceName} (${bus.departureTime})`, 'info');
    },

    /**
     * Render the 40-Seat Bus Grid Layout with Aisle for Selected Bus
     */
    renderSeatGrid: function () {
      const gridContainer = document.getElementById('bus-seat-grid');
      if (!gridContainer || !window.BusStorage) return;

      const currentBus = BusStorage.getSelectedBus();
      const travelDate = BusStorage.getSelectedDate();
      const bookedSeats = BusStorage.getBookedSeatNumbers(currentBus.id, travelDate);

      // Update Header on Left Deck
      const deckBusName = document.getElementById('deck-bus-name');
      const deckBusDetails = document.getElementById('deck-bus-details');
      const deckBusSlotBadge = document.getElementById('deck-bus-slot-badge');

      if (deckBusName) deckBusName.textContent = currentBus.serviceName;
      if (deckBusDetails) deckBusDetails.textContent = `Coach #${currentBus.busNumber} • Departure: ${currentBus.departureTime} • Date: ${travelDate}`;
      if (deckBusSlotBadge) {
        deckBusSlotBadge.textContent = `${currentBus.slot} Slot`;
        deckBusSlotBadge.className = `badge ${currentBus.slot === 'Morning' ? 'slot-badge-morning' : currentBus.slot === 'Afternoon' ? 'slot-badge-afternoon' : currentBus.slot === 'Evening' ? 'slot-badge-evening' : 'slot-badge-night'}`;
      }

      gridContainer.innerHTML = '';

      // 40 seats arranged in 10 rows (2 Left - Aisle - 2 Right)
      const totalRows = 10;

      for (let r = 1; r <= totalRows; r++) {
        const rowEl = document.createElement('div');
        rowEl.className = 'seat-row';

        // Left pair of seats
        const leftPair = document.createElement('div');
        leftPair.className = 'seat-pair';

        const seat1 = (r - 1) * 4 + 1;
        const seat2 = (r - 1) * 4 + 2;
        leftPair.appendChild(this.createSeatElement(seat1, bookedSeats));
        leftPair.appendChild(this.createSeatElement(seat2, bookedSeats));

        // Center Aisle
        const aisle = document.createElement('div');
        aisle.className = 'aisle-walkway';
        aisle.textContent = `R${r}`;

        // Right pair of seats
        const rightPair = document.createElement('div');
        rightPair.className = 'seat-pair';

        const seat3 = (r - 1) * 4 + 3;
        const seat4 = (r - 1) * 4 + 4;
        rightPair.appendChild(this.createSeatElement(seat3, bookedSeats));
        rightPair.appendChild(this.createSeatElement(seat4, bookedSeats));

        rowEl.appendChild(leftPair);
        rowEl.appendChild(aisle);
        rowEl.appendChild(rightPair);

        gridContainer.appendChild(rowEl);
      }
    },

    /**
     * Create individual seat DOM element
     */
    createSeatElement: function (seatNumber, bookedSeats) {
      const isBooked = bookedSeats.includes(seatNumber);
      const isSelected = this.selectedSeats.includes(seatNumber);

      const seat = document.createElement('div');
      seat.className = 'seat-item';
      seat.dataset.seat = seatNumber;
      seat.textContent = seatNumber;

      if (isBooked) {
        seat.classList.add('booked');
        seat.setAttribute('title', `Seat ${seatNumber} is already booked on this coach`);
        seat.onclick = () => {
          this.showToast(`Seat #${seatNumber} is already booked on this coach and cannot be selected.`, 'warning');
        };
      } else if (isSelected) {
        seat.classList.add('selected');
        seat.setAttribute('title', `Seat ${seatNumber} is selected`);
        seat.onclick = () => this.toggleSeat(seatNumber);
      } else {
        seat.classList.add('available');
        seat.setAttribute('title', `Seat ${seatNumber} is available`);
        seat.onclick = () => this.toggleSeat(seatNumber);
      }

      return seat;
    },

    /**
     * Toggle selection of an available seat
     */
    toggleSeat: function (seatNumber) {
      const currentBus = BusStorage.getSelectedBus();
      const travelDate = BusStorage.getSelectedDate();

      if (BusStorage.isSeatBooked(seatNumber, currentBus.id, travelDate)) {
        this.showToast(`Seat #${seatNumber} is already booked!`, 'warning');
        return;
      }

      const index = this.selectedSeats.indexOf(seatNumber);
      if (index > -1) {
        this.selectedSeats.splice(index, 1);
        this.showToast(`Seat #${seatNumber} unselected`, 'info');
      } else {
        this.selectedSeats.push(seatNumber);
        this.selectedSeats.sort((a, b) => a - b);
        this.showToast(`Seat #${seatNumber} selected`, 'success');
      }

      this.renderSeatGrid();
      this.updateSelectionSummary();
    },

    /**
     * Update dynamic reservation summary and submit button
     */
    updateSelectionSummary: function () {
      const container = document.getElementById('selected-seats-container');
      const fareEl = document.getElementById('total-fare-amount');
      const badgeEl = document.getElementById('seat-count-badge');
      const submitBtn = document.getElementById('btn-submit-booking');

      if (!container || !fareEl || !badgeEl || !submitBtn) return;

      const currentBus = BusStorage.getSelectedBus();
      const travelDate = BusStorage.getSelectedDate();
      const count = this.selectedSeats.length;
      const totalFare = count * currentBus.farePerSeat;

      // Update Summary Header elements
      const sumName = document.getElementById('summary-bus-name');
      const sumRoute = document.getElementById('summary-bus-route');
      const sumDateSlot = document.getElementById('summary-bus-date-slot');
      const sumTime = document.getElementById('summary-bus-time');
      const sumFare = document.getElementById('summary-bus-fare');

      if (sumName) sumName.textContent = currentBus.serviceName;
      if (sumRoute) sumRoute.textContent = `${currentBus.busNumber} | ${currentBus.routeFrom.split('(')[0]} ➔ ${currentBus.routeTo.split('(')[0]}`;
      if (sumDateSlot) sumDateSlot.textContent = `${travelDate} (${currentBus.slot} Slot)`;
      if (sumTime) sumTime.textContent = currentBus.departureTime;
      if (sumFare) sumFare.textContent = `$${currentBus.farePerSeat.toFixed(2)}`;

      badgeEl.textContent = `${count} Seat${count === 1 ? '' : 's'} Selected`;
      fareEl.textContent = `$${totalFare.toFixed(2)}`;

      if (count === 0) {
        container.innerHTML = '<span class="text-muted fst-italic small">No seats selected yet. Please click on the available seats on the bus map.</span>';
        submitBtn.disabled = true;
      } else {
        container.innerHTML = '';
        this.selectedSeats.forEach(seatNum => {
          const tag = document.createElement('span');
          tag.className = 'selected-seat-tag';
          tag.innerHTML = `Seat #${seatNum} <i class="bi bi-x-circle-fill" style="cursor: pointer;" onclick="PTSApp.toggleSeat(${seatNum})"></i>`;
          container.appendChild(tag);
        });
        submitBtn.disabled = false;
      }
    },

    /**
     * Handle passenger registration & booking submission
     */
    handleBookingSubmit: function (event) {
      event.preventDefault();
      const form = document.getElementById('passenger-form');

      if (this.selectedSeats.length === 0) {
        this.showToast('Please select at least one seat on the bus map before submitting.', 'warning');
        return;
      }

      const nameInput = document.getElementById('passenger-name');
      const ageInput = document.getElementById('passenger-age');
      const genderInput = document.getElementById('passenger-gender');
      const mobileInput = document.getElementById('passenger-mobile');

      // Validation
      const name = nameInput.value.trim();
      const age = parseInt(ageInput.value, 10);
      const gender = genderInput.value;
      const mobile = mobileInput.value.trim();

      let isValid = true;

      if (!name || name.length < 3) {
        nameInput.classList.add('is-invalid');
        isValid = false;
      } else {
        nameInput.classList.remove('is-invalid');
        nameInput.classList.add('is-valid');
      }

      if (isNaN(age) || age < 1 || age > 120) {
        ageInput.classList.add('is-invalid');
        isValid = false;
      } else {
        ageInput.classList.remove('is-invalid');
        ageInput.classList.add('is-valid');
      }

      if (!gender) {
        genderInput.classList.add('is-invalid');
        isValid = false;
      } else {
        genderInput.classList.remove('is-invalid');
        genderInput.classList.add('is-valid');
      }

      const mobilePattern = /^[0-9]{10}$/;
      if (!mobilePattern.test(mobile)) {
        mobileInput.classList.add('is-invalid');
        isValid = false;
      } else {
        mobileInput.classList.remove('is-invalid');
        mobileInput.classList.add('is-valid');
      }

      if (!isValid) {
        this.showToast('Please complete all passenger details accurately.', 'error');
        return;
      }

      const currentBus = BusStorage.getSelectedBus();
      const travelDate = BusStorage.getSelectedDate();

      // Save Booking to LocalStorage
      const bookingData = {
        busId: currentBus.id,
        travelDate: travelDate,
        timeSlot: currentBus.slot,
        passenger: { name, age, gender, mobile },
        seats: [...this.selectedSeats]
      };

      const result = BusStorage.createBooking(bookingData);

      if (!result.success) {
        this.showToast(result.message, 'error');
        this.renderSeatGrid();
        return;
      }

      // Clear state and inputs
      const bookedRecord = result.booking;
      this.selectedSeats = [];
      form.reset();
      form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));
      
      this.renderAvailableBuses();
      this.renderSeatGrid();
      this.updateSelectionSummary();
      this.updateHomeStats();

      this.showToast(`Booking Successful! ID: ${bookedRecord.id}`, 'success');

      // Display the printable ticket immediately
      this.showTicket(bookedRecord.id);
    },

    /**
     * Render My Bookings List
     */
    renderBookingsList: function () {
      const container = document.getElementById('bookings-list-container');
      if (!container || !window.BusStorage) return;

      const searchInput = document.getElementById('booking-search-input');
      const query = searchInput ? searchInput.value.trim() : '';

      let bookings = query ? BusStorage.searchBookings(query) : BusStorage.getAllBookings();

      // Apply status filter
      if (this.statusFilter !== 'ALL') {
        bookings = bookings.filter(b => b.status === this.statusFilter);
      }

      if (bookings.length === 0) {
        container.innerHTML = `
          <div class="custom-card p-5 text-center text-muted">
            <i class="bi bi-ticket-detailed fs-1 text-secondary mb-3 d-block"></i>
            <h5 class="fw-bold text-dark">No Bookings Found</h5>
            <p class="small text-muted mb-3">No reservation records matched your search criteria or filter.</p>
            <button class="btn btn-primary-custom btn-sm" onclick="PTSApp.navigate('book')">
              <i class="bi bi-plus-circle"></i> Reserve a New Seat
            </button>
          </div>
        `;
        return;
      }

      container.innerHTML = '';

      bookings.forEach(booking => {
        const isConfirmed = booking.status === 'Confirmed';
        const card = document.createElement('div');
        card.className = 'custom-card p-4 mb-3';

        const seatsFormatted = Array.isArray(booking.seats)
          ? booking.seats.map(s => `<span class="badge bg-primary-soft text-primary-custom me-1">#${s}</span>`).join('')
          : 'N/A';

        const statusBadge = isConfirmed
          ? '<span class="badge-confirmed"><i class="bi bi-check-circle-fill me-1"></i> Confirmed</span>'
          : '<span class="badge-cancelled"><i class="bi bi-x-circle-fill me-1"></i> Cancelled</span>';

        const busInfo = booking.busDetails || {};
        const travelDate = booking.travelDate || '2026-11-25';
        const slot = booking.timeSlot || busInfo.slot || 'Morning';

        const cancelInfo = (!isConfirmed && booking.cancelledDate)
          ? `<div class="small text-danger mt-1"><i class="bi bi-info-circle me-1"></i> Cancelled on ${booking.cancelledDate} ${booking.cancelReason ? '(' + booking.cancelReason + ')' : ''}</div>`
          : '';

        const cancelActionBtn = isConfirmed
          ? `<button class="btn btn-outline-danger btn-sm" onclick="PTSApp.openCancelModal('${booking.id}')">
               <i class="bi bi-x-circle"></i> Cancel Reservation
             </button>`
          : `<span class="text-muted small fst-italic">Seats released to pool</span>`;

        card.innerHTML = `
          <div class="row align-items-center g-3">
            <div class="col-md-3">
              <div class="fw-bold fs-5 text-dark mb-1">${booking.id}</div>
              <div class="text-muted small"><i class="bi bi-calendar3 me-1"></i> Booked: ${booking.bookingDate}</div>
              <div class="mt-2">${statusBadge}</div>
            </div>

            <div class="col-md-4">
              <div class="fw-bold text-dark mb-1">${booking.passenger.name} (${booking.passenger.age} yrs, ${booking.passenger.gender})</div>
              <div class="text-muted small mb-1"><i class="bi bi-telephone me-1"></i> ${booking.passenger.mobile}</div>
              <div class="small mb-1 text-primary-custom fw-semibold">
                <i class="bi bi-bus-front me-1"></i> ${busInfo.serviceName || 'SkyRoute Express'} (${busInfo.busNumber || 'Coach'})
              </div>
              <div class="small text-muted mb-2">
                <i class="bi bi-clock-history me-1"></i> <strong>Travel:</strong> ${travelDate} &bull; <span class="badge bg-light text-dark border">${slot} Slot</span>
              </div>
              <div class="small">
                <strong>Assigned Seats:</strong> ${seatsFormatted}
              </div>
              ${cancelInfo}
            </div>

            <div class="col-md-2 text-md-center">
              <div class="text-muted small">Total Paid</div>
              <div class="h4 fw-bold text-primary-custom mb-0">$${Number(booking.totalAmount).toFixed(2)}</div>
              <small class="text-muted">Dep: ${busInfo.departureTime || 'Scheduled'}</small>
            </div>

            <div class="col-md-3 text-md-end d-flex flex-column gap-2 justify-content-center">
              <button class="btn btn-outline-custom btn-sm" onclick="PTSApp.showTicket('${booking.id}')">
                <i class="bi bi-printer"></i> View & Print Ticket
              </button>
              ${cancelActionBtn}
            </div>
          </div>
        `;

        container.appendChild(card);
      });
    },

    /**
     * Search filter inside My Bookings
     */
    filterBookingsList: function () {
      this.renderBookingsList();
    },

    /**
     * Clear search input
     */
    clearBookingSearch: function () {
      const searchInput = document.getElementById('booking-search-input');
      if (searchInput) searchInput.value = '';
      this.renderBookingsList();
    },

    /**
     * Set Status Filter (All, Confirmed, Cancelled)
     */
    setStatusFilter: function (status) {
      this.statusFilter = status;
      document.querySelectorAll('.btn-filter-status').forEach(btn => {
        btn.classList.remove('active');
        if (btn.dataset.status === status) {
          btn.classList.add('active');
        }
      });
      this.renderBookingsList();
    },

    /**
     * Open Cancellation Confirmation Modal
     */
    openCancelModal: function (bookingId) {
      const booking = BusStorage.getBookingById(bookingId);
      if (!booking) {
        this.showToast('Booking record not found.', 'error');
        return;
      }

      this.pendingCancelId = bookingId;
      document.getElementById('cancel-modal-booking-id').textContent = booking.id;
      document.getElementById('cancel-modal-seats').textContent = Array.isArray(booking.seats)
        ? booking.seats.join(', ')
        : booking.seats;

      const reasonInput = document.getElementById('cancel-reason-input');
      if (reasonInput) reasonInput.value = '';

      if (this.cancelModalInstance) {
        this.cancelModalInstance.show();
      }
    },

    /**
     * Execute Booking Cancellation
     */
    executeCancellation: function () {
      if (!this.pendingCancelId) return;

      const reasonInput = document.getElementById('cancel-reason-input');
      const reason = reasonInput ? reasonInput.value.trim() : '';

      const result = BusStorage.cancelBooking(this.pendingCancelId, reason);

      if (this.cancelModalInstance) {
        this.cancelModalInstance.hide();
      }

      if (result.success) {
        this.showToast(result.message, 'success');
        this.pendingCancelId = null;

        // Re-render views
        this.renderBookingsList();
        this.updateHomeStats();
        if (this.currentView === 'admin') {
          this.renderAdminView();
        }
        if (this.currentView === 'book') {
          this.renderAvailableBuses();
          this.renderSeatGrid();
        }
      } else {
        this.showToast(result.message, 'error');
      }
    },

    /**
     * Show Boarding Pass Ticket Modal
     */
    showTicket: function (bookingId) {
      const booking = BusStorage.getBookingById(bookingId);
      if (!booking) {
        this.showToast('Ticket record not found.', 'error');
        return;
      }

      const busDetails = booking.busDetails || {};
      const config = BusStorage.getConfig();

      // Populate Ticket Elements
      document.getElementById('ticket-id-badge').textContent = booking.id;
      document.getElementById('ticket-status-label').textContent = booking.status;
      document.getElementById('ticket-status-label').className = booking.status === 'Confirmed' ? 'small mt-1 text-white fw-bold' : 'small mt-1 text-warning fw-bold';

      document.getElementById('ticket-route-from').textContent = busDetails.routeFrom || config.routeFrom;
      document.getElementById('ticket-route-to').textContent = busDetails.routeTo || config.routeTo;
      document.getElementById('ticket-departure-time').textContent = busDetails.departureTime || config.departureTime;
      document.getElementById('ticket-bus-num').textContent = busDetails.busNumber || config.busNumber;

      const ticketTravelDate = document.getElementById('ticket-travel-date');
      const ticketTimeSlot = document.getElementById('ticket-time-slot');
      if (ticketTravelDate) ticketTravelDate.textContent = booking.travelDate || '2026-11-25';
      if (ticketTimeSlot) ticketTimeSlot.textContent = `${booking.timeSlot || busDetails.slot || 'Morning'} Slot`;

      const bookingDateEl = document.getElementById('ticket-booking-date');
      if (bookingDateEl) bookingDateEl.textContent = booking.bookingDate || 'N/A';

      document.getElementById('ticket-passenger-name').textContent = booking.passenger.name;
      document.getElementById('ticket-passenger-mobile').textContent = booking.passenger.mobile;
      document.getElementById('ticket-passenger-details').textContent = `${booking.passenger.age} yrs / ${booking.passenger.gender}`;
      
      const seatsText = Array.isArray(booking.seats) ? booking.seats.join(', ') : booking.seats;
      document.getElementById('ticket-seat-numbers').textContent = `Seat #${seatsText}`;
      document.getElementById('ticket-barcode-text').textContent = `*${booking.id}*`;

      const ticketSeatType = document.getElementById('ticket-seat-type');
      if (ticketSeatType) {
        ticketSeatType.textContent = `${busDetails.serviceName || 'SkyRoute Express'} (${busDetails.busType || 'Luxury Coach'})`;
      }

      const paymentBadge = document.getElementById('ticket-payment-status');
      if (paymentBadge) {
        if (booking.status === 'Confirmed') {
          paymentBadge.className = 'badge bg-success-subtle text-success border border-success-subtle';
          paymentBadge.textContent = `PAID - $${Number(booking.totalAmount).toFixed(2)}`;
        } else {
          paymentBadge.className = 'badge bg-danger-subtle text-danger border border-danger-subtle';
          paymentBadge.textContent = `CANCELLED - $${Number(booking.totalAmount).toFixed(2)}`;
        }
      }

      if (this.ticketModalInstance) {
        this.ticketModalInstance.show();
      }
    },

    /**
     * Admin Portal: Login / Dashboard View Handler
     */
    renderAdminView: function () {
      const loginBox = document.getElementById('admin-login-box');
      const dashboardContent = document.getElementById('admin-dashboard-content');

      if (!loginBox || !dashboardContent) return;

      if (!BusStorage.isAdminLoggedIn()) {
        loginBox.classList.remove('d-none');
        dashboardContent.classList.add('d-none');
      } else {
        loginBox.classList.add('d-none');
        dashboardContent.classList.remove('d-none');
        this.renderAdminDashboardStats();
        this.renderAdminTable();
      }
    },

    /**
     * Handle Admin Login
     */
    handleAdminLogin: function (event) {
      event.preventDefault();
      const user = document.getElementById('admin-username').value.trim();
      const pass = document.getElementById('admin-password').value.trim();

      if (BusStorage.loginAdmin(user, pass)) {
        this.showToast('Welcome, Administrator! Logged in successfully.', 'success');
        this.renderAdminView();
      } else {
        this.showToast('Invalid credentials. Use admin / admin123', 'error');
      }
    },

    /**
     * Handle Admin Logout
     */
    handleAdminLogout: function () {
      BusStorage.logoutAdmin();
      this.showToast('Logged out of Admin Portal.', 'info');
      this.renderAdminView();
    },

    /**
     * Render Admin Dashboard Metrics
     */
    renderAdminDashboardStats: function () {
      const stats = BusStorage.getStatistics();

      document.getElementById('adm-total-seats').textContent = stats.totalSeats;
      document.getElementById('adm-avail-seats').textContent = stats.availableSeatsCount;
      document.getElementById('adm-booked-seats').textContent = stats.bookedSeatsCount;
      document.getElementById('adm-total-bookings').textContent = stats.totalBookingsCount;
      document.getElementById('adm-cancelled-bookings').textContent = stats.cancelledBookingsCount;
      document.getElementById('adm-revenue').textContent = `$${stats.totalRevenue}`;

      const occupancyBadge = document.getElementById('adm-occupancy-badge');
      const occupancyBar = document.getElementById('adm-occupancy-bar');
      if (occupancyBadge) occupancyBadge.textContent = `${stats.occupancyPercent}% Occupied`;
      if (occupancyBar) {
        occupancyBar.style.width = `${stats.occupancyPercent}%`;
        occupancyBar.setAttribute('aria-valuenow', stats.occupancyPercent);
      }
    },

    /**
     * Render Admin Passenger & Reservation Management Table
     */
    renderAdminTable: function () {
      const tbody = document.getElementById('adm-records-tbody');
      const emptyMsg = document.getElementById('adm-empty-table-msg');
      if (!tbody || !emptyMsg) return;

      const searchVal = (document.getElementById('adm-table-search')?.value || '').trim().toLowerCase();
      const statusFilterVal = document.getElementById('adm-table-status-filter')?.value || 'ALL';

      let bookings = BusStorage.getAllBookings();

      // Filter by status
      if (statusFilterVal !== 'ALL') {
        bookings = bookings.filter(b => b.status === statusFilterVal);
      }

      // Filter by search text
      if (searchVal) {
        bookings = bookings.filter(b => {
          const matchId = b.id.toLowerCase().includes(searchVal);
          const matchName = b.passenger && b.passenger.name.toLowerCase().includes(searchVal);
          const matchMobile = b.passenger && b.passenger.mobile.includes(searchVal);
          const matchSeats = Array.isArray(b.seats) && b.seats.join(',').includes(searchVal);
          const matchBus = b.busDetails && (b.busDetails.busNumber || '').toLowerCase().includes(searchVal);
          return matchId || matchName || matchMobile || matchSeats || matchBus;
        });
      }

      tbody.innerHTML = '';

      if (bookings.length === 0) {
        emptyMsg.classList.remove('d-none');
        return;
      }

      emptyMsg.classList.add('d-none');

      bookings.forEach(b => {
        const isConfirmed = b.status === 'Confirmed';
        const tr = document.createElement('tr');

        const seatTags = Array.isArray(b.seats)
          ? b.seats.map(s => `<span class="badge bg-primary-soft text-primary-custom me-1">#${s}</span>`).join('')
          : 'N/A';

        const statusHtml = isConfirmed
          ? `<span class="badge bg-success-subtle text-success border border-success-subtle px-2 py-1"><i class="bi bi-check-circle me-1"></i> Confirmed</span>`
          : `<span class="badge bg-danger-subtle text-danger border border-danger-subtle px-2 py-1"><i class="bi bi-x-circle me-1"></i> Cancelled</span>`;

        const cancelAction = isConfirmed
          ? `<button class="btn btn-outline-danger btn-sm py-0 px-2" title="Cancel Booking" onclick="PTSApp.openCancelModal('${b.id}')">
               <i class="bi bi-x"></i> Cancel
             </button>`
          : `<span class="text-muted small">Released</span>`;

        const busInfo = b.busDetails || {};
        const dateSlotStr = `${b.travelDate || '2026-11-25'} (${b.timeSlot || busInfo.slot || 'Morning'})`;

        tr.innerHTML = `
          <td><strong>${b.id}</strong></td>
          <td>
            <div class="fw-bold">${b.passenger.name}</div>
            <small class="text-muted">${busInfo.busNumber || 'Coach'}</small>
            ${b.isDemo ? '<span class="badge bg-light text-muted border ms-1" style="font-size: 0.68rem;">Demo Data</span>' : ''}
          </td>
          <td>${b.passenger.age} / ${b.passenger.gender}</td>
          <td>${b.passenger.mobile}</td>
          <td>${seatTags}</td>
          <td>
            <div><small class="fw-semibold text-dark">${dateSlotStr}</small></div>
            <small class="text-muted" style="font-size: 0.75rem;">Booked: ${b.bookingDate}</small>
          </td>
          <td><strong class="text-primary-custom">$${Number(b.totalAmount).toFixed(2)}</strong></td>
          <td>${statusHtml}</td>
          <td class="text-end">
            <div class="d-inline-flex gap-1">
              <button class="btn btn-outline-custom btn-sm py-0 px-2" title="View Boarding Pass" onclick="PTSApp.showTicket('${b.id}')">
                <i class="bi bi-printer"></i>
              </button>
              ${cancelAction}
            </div>
          </td>
        `;

        tbody.appendChild(tr);
      });
    },

    /**
     * Filter Admin Table on user input
     */
    filterAdminTable: function () {
      this.renderAdminTable();
    },

    /**
     * Reset Storage to Sample Demo Data
     */
    handleResetDemoData: function () {
      if (confirm('Are you sure you want to restore demo sample data? Current bookings will be overwritten with test records.')) {
        BusStorage.resetDemoData();
        this.showToast('Demo data restored successfully.', 'success');
        this.renderAdminDashboardStats();
        this.renderAdminTable();
        this.updateHomeStats();
        this.renderAvailableBuses();
        this.renderSeatGrid();
      }
    },

    /**
     * Clear all bookings data
     */
    handleClearAllData: function () {
      if (confirm('Warning: Are you sure you want to clear ALL reservation records? All seats will become available.')) {
        BusStorage.clearAllData();
        this.showToast('All bookings cleared. 40 seats are now available.', 'info');
        this.renderAdminDashboardStats();
        this.renderAdminTable();
        this.updateHomeStats();
        this.renderAvailableBuses();
        this.renderSeatGrid();
      }
    },

    /**
     * Export all bookings as JSON file download
     */
    exportBookingsJSON: function () {
      const data = BusStorage.getAllBookings();
      const jsonStr = JSON.stringify(data, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);

      const a = document.createElement('a');
      a.href = url;
      a.download = `skyroute_bookings_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      this.showToast('Bookings successfully exported as JSON.', 'success');
    },

    /**
     * Toast Notification Generator
     */
    showToast: function (message, type = 'info') {
      const container = document.getElementById('toastContainer');
      if (!container) return;

      const toast = document.createElement('div');
      toast.className = 'custom-toast mb-2 animate__animated animate__fadeInUp';

      let icon = '<i class="bi bi-info-circle-fill text-info me-2"></i>';
      if (type === 'success') {
        toast.style.borderLeftColor = '#22C55E';
        icon = '<i class="bi bi-check-circle-fill text-success me-2"></i>';
      } else if (type === 'error') {
        toast.style.borderLeftColor = '#EF4444';
        icon = '<i class="bi bi-exclamation-circle-fill text-danger me-2"></i>';
      } else if (type === 'warning') {
        toast.style.borderLeftColor = '#F59E0B';
        icon = '<i class="bi bi-exclamation-triangle-fill text-warning me-2"></i>';
      }

      toast.innerHTML = `
        <div class="d-flex align-items-center justify-content-between">
          <div class="d-flex align-items-center">
            ${icon}
            <span class="small fw-semibold text-dark">${message}</span>
          </div>
          <button type="button" class="btn-close btn-close-sm ms-2" style="font-size: 0.75rem;" onclick="this.parentElement.parentElement.remove()"></button>
        </div>
      `;

      container.appendChild(toast);

      setTimeout(() => {
        if (toast && toast.parentElement) {
          toast.remove();
        }
      }, 4000);
    }
  };

  // Expose to window and run on DOM load
  window.PTSApp = PTSApp;
  document.addEventListener('DOMContentLoaded', () => PTSApp.init());

})(window, document);
